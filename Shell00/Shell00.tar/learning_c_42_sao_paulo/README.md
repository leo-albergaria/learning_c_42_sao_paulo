<img src="https://user-images.githubusercontent.com/63436406/161079534-b6afbfb7-34b1-491e-9578-9b9c2a534ae6.png" align="left" height="150px" width="150px">
<h1>  🎲 42 São Paulo </h1>
<p> Será apresentado materiais desenvolvidos na linguagem C tratados nos processos de avaliação. Grupo - Vila 6x7</p>
<br>

---
<p align="right">
# Hello <img src="https://acegif.com/wp-content/gifs/ola-47.gif" width="29px">
# Um pouco sobre mim #
</p>    
<p align="right">
    <a href="https://web.dio.me/users/leo_albergaria?tab=achievements">
        <img style="border-radius: 50px; height: 50px; width: 90px"
             src="https://user-images.githubusercontent.com/63436406/155859846-da9d78e9-c7c4-47ca-a95c-43fed103bd46.png"/>
    <a href="https://www.linkedin.com/in/adm-leo-albergaria/">
        <img style="border-radius: 50px; height: 50px; width: 90px"
             src="https://user-images.githubusercontent.com/63436406/155859988-26ceade2-4e04-473a-8a26-796b145a4224.png" />
    <a href="https://github.com/leo-albergaria">
        <img style="border-radius: 50px; height: 50px; width: 90px"
             src="https://user-images.githubusercontent.com/63436406/155860021-d9d51434-9fe1-4233-a70a-6b69d5f85792.png" /></a>
</p>
